<!DOCTYPE html>
<html lang="en">
<head>
    <title>Webpage Design</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">MODERN COMMUNITY</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="myunit.php">MYUNIT</a></li>
                    <li><a href="community.php">COMMUNITY</a></li>
                    <li><a href="discover.php">DISCOVER</a></li>
                    <li><a href="logout.php">Log Out</a></li>
                    
                </ul>
            </div>

            <!-- <div class="search">
                <input class="srch" type="search" name="" placeholder="Type To text">
                <a href="#"> <button class="btn">Search</button></a>
            </div> -->

        </div> 
        <div class="content">
            <h1>Family Happiness with<br><span>Security &</span> <br>Benefits</h1>
            <p class="par">This app benefit the community with more services enjoy with happiness<br>
            </b>and any emergency condition to contact with community people for help</b><br>
                </b>JOIN US</b></p>

                    </div>
                </div>
        </div>
    </div>
    <script src= "1.jpj"></script>
</body>
</html>