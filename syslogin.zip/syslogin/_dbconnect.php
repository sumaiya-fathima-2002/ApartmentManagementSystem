<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "nice";

$conn = mysqli_connect($server,$username,$password,$database);

?>